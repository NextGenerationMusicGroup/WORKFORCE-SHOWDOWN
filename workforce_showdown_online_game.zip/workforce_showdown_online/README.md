# Workforce Showdown: Employees vs Bosses

This is an online, two-player browser fighting-game starter project. Players connect to the same hosted website, create/join a room using a code, and fight in real time.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in a browser.
5. Open the same address in a second browser/device on the same network for local testing. For remote players, deploy the project to a public Node.js host.

## Deploy online
Deploy this whole project to a Node.js hosting service that supports persistent WebSocket connections (for example, Render or Railway). Set the start command to `npm start`. The host will provide a public HTTPS URL to share with players.

## Gameplay
- Create Match gives you a five-character room code.
- Send the game URL and room code to a friend.
- Your friend opens the same URL and joins using the code.
- Controls: A/D move, W jump, F attack, G special, S block; mobile touch buttons are included.
- Choose Employee or Boss before creating/joining.

## Notes
- This is a starter prototype with simple 2D placeholder fighters, not a finished commercial game.
- It uses Socket.IO for online connections. For production, add server-side validation/rate limiting, reconnection handling, abuse prevention, privacy information, and more robust authoritative hit detection.
- Do not present placeholder graphics as likenesses of real coworkers without permission.
