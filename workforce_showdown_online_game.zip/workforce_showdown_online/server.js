const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Workforce Showdown" }));

const rooms = new Map();
const ARENA_W = 900, ARENA_H = 500;
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
function makeFighter(id, slot, role) {
  return {
    id, slot, role, x: slot === 1 ? 250 : 650, y: 370,
    hp: 100, facing: slot === 1 ? 1 : -1,
    attacking: 0, blocking: false, cooldown: 0, wins: 0,
    name: role === "employee" ? (slot === 1 ? "Shift Starter" : "Team Player") : (slot === 1 ? "Floor Manager" : "The Boss")
  };
}
function roomState(room) {
  return { code: room.code, players: [...room.players.values()].map(p => ({
    id:p.id, slot:p.slot, role:p.role, x:p.x, y:p.y, hp:p.hp, facing:p.facing,
    attacking:p.attacking, blocking:p.blocking, wins:p.wins, name:p.name
  })), started: room.players.size === 2, roundOver: room.roundOver || false, winner: room.winner || null };
}
function emitRoom(room) { io.to(room.code).emit("state", roomState(room)); }
function resetRound(room) {
  const ps = [...room.players.values()];
  ps.forEach((p, i) => { p.x = i === 0 ? 250 : 650; p.y=370; p.hp=100; p.facing=i===0?1:-1; p.attacking=0; p.blocking=false; p.cooldown=0; });
  room.roundOver = false; room.winner = null;
}
function getRoomForSocket(socket) {
  for (const room of rooms.values()) if (room.players.has(socket.id)) return room;
  return null;
}
io.on("connection", socket => {
  socket.on("createRoom", ({ role } = {}) => {
    let code;
    do { code = Math.random().toString(36).slice(2, 7).toUpperCase(); } while (rooms.has(code));
    const room = { code, players: new Map(), roundOver: false, winner: null };
    const normalizedRole = role === "boss" ? "boss" : "employee";
    room.players.set(socket.id, { ...makeFighter(socket.id, 1, normalizedRole), input: {} });
    rooms.set(code, room); socket.join(code);
    socket.emit("joined", { code, slot: 1, role: normalizedRole }); emitRoom(room);
  });
  socket.on("joinRoom", ({ code, role } = {}) => {
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return socket.emit("notice", "Room not found. Check the code with your opponent.");
    if (room.players.size >= 2) return socket.emit("notice", "This room already has two players.");
    const normalizedRole = role === "boss" ? "boss" : "employee";
    room.players.set(socket.id, { ...makeFighter(socket.id, 2, normalizedRole), input: {} });
    socket.join(code); socket.emit("joined", { code, slot: 2, role: normalizedRole });
    io.to(code).emit("notice", "Both fighters are connected. Fight!");
    emitRoom(room);
  });
  socket.on("input", input => {
    const room = getRoomForSocket(socket); if (!room || room.roundOver) return;
    const p = room.players.get(socket.id); if (!p) return;
    p.input = {
      left: !!input.left, right: !!input.right, jump: !!input.jump,
      attack: !!input.attack, block: !!input.block, special: !!input.special
    };
    if (input.attack && p.cooldown <= 0) { p.attacking = 12; p.cooldown = 24; }
    if (input.special && p.cooldown <= 0) { p.attacking = 20; p.cooldown = 48; }
    p.blocking = !!input.block;
  });
  socket.on("rematch", () => {
    const room = getRoomForSocket(socket); if (!room || room.players.size !== 2) return;
    resetRound(room); emitRoom(room);
  });
  socket.on("disconnect", () => {
    const room = getRoomForSocket(socket);
    if (room) {
      room.players.delete(socket.id);
      if (!room.players.size) rooms.delete(room.code);
      else { io.to(room.code).emit("notice", "Your opponent disconnected."); emitRoom(room); }
    }
  });
});

setInterval(() => {
  for (const room of rooms.values()) {
    if (room.players.size !== 2 || room.roundOver) continue;
    const ps = [...room.players.values()];
    for (const p of ps) {
      const inp = p.input || {};
      if (inp.left) p.x -= 5;
      if (inp.right) p.x += 5;
      if (inp.jump && p.y >= 370) p.y = 290;
      else if (p.y < 370) p.y = Math.min(370, p.y + 5);
      p.x = clamp(p.x, 55, ARENA_W - 55);
      p.cooldown = Math.max(0, p.cooldown - 1);
      p.attacking = Math.max(0, p.attacking - 1);
    }
    ps[0].facing = ps[1].x >= ps[0].x ? 1 : -1;
    ps[1].facing = -ps[0].facing;
    for (const attacker of ps) {
      if (attacker.attacking === 10 || attacker.attacking === 18) {
        const target = ps.find(p => p.id !== attacker.id);
        if (Math.abs(target.x - attacker.x) < 105 && Math.abs(target.y - attacker.y) < 100) {
          const damage = attacker.attacking === 18 ? 16 : 9;
          target.hp = Math.max(0, target.hp - (target.blocking ? Math.ceil(damage * 0.25) : damage));
        }
      }
    }
    const defeated = ps.find(p => p.hp <= 0);
    if (defeated) {
      room.roundOver = true;
      room.winner = ps.find(p => p.id !== defeated.id).id;
      ps.find(p => p.id === room.winner).wins += 1;
      io.to(room.code).emit("notice", ps.find(p => p.id === room.winner).name + " wins the round!");
    }
    emitRoom(room);
  }
}, 1000 / 30);

server.listen(PORT, () => console.log(`Workforce Showdown listening on ${PORT}`));
